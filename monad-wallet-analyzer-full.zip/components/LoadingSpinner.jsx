import React from 'react';
export default function LoadingSpinner(){ return <div className="text-gray-400">Loading...</div>; }
